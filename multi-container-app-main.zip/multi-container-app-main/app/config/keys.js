module.exports = {
    mongoProdURI: 'mongodb://todo-database:27017/todoapp',
};